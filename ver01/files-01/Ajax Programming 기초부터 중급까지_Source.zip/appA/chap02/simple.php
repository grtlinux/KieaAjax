<?php
	header("Content-Type: text/plain; charset=utf-8");
	echo "simple.jsp의 응답 텍스트";
?>